(function(){
	var d = document.createElement('base');
	d.target = "_blank";
	var head = document.querySelectorAll("head")[0];
	head.appendChild(d);
	d = document.createElement('style');
	d.appendChild(document.createTextNode(".post-text code { font-size: 17px;} pre code{ white-space: pre-wrap; } .CodeMirror{ font-size:14px;}"));
	head.appendChild(d);
	
	[].forEach.call(document.querySelectorAll("code"),
			function(c){
				var val = c.textContent || c.innerText;
		  		val = val.slice(val.match(/^\s*/)[0].length, val.length - val.match(/\s*$/)[0].length);
				c = c.parentNode;
				if (val.split(/\r\n|\r|\n/).length>1){					
					var editor = CodeMirror(function(elt) {
							var parentDiv = document.createElement("div");
							
							parentDiv.setAttribute('style', "width:"+c.offsetWidth+"px;height:"+c.offsetHeight+"px; overflow-y: auto; position:relative");
							parentDiv.appendChild(elt);
							c.parentNode.replaceChild(parentDiv, c);
						}, {
							value: val,
							theme: "night",
							mode: {name: "javascript", globalVars: true},
							highlightSelectionMatches: {showToken: /\w/, delay: 3000},
							matchBrackets: true,
							viewportMargin: Infinity,
							lineNumbers: false,
							lineWrapping: true,
							scrollbarStyle: "overlay",
							extraKeys: {
								"Ctrl-Space": function(cm, event){cm.showHint({hint: CodeMirror.hint.anyword});},
								"Insert": function(cm, event){return},
								"Alt-F": "findPersistent",
 								"F11": function(cm) {
								  cm.setOption("fullScreen", !cm.getOption("fullScreen"));
								}
							}
						});
					editor.on("mousedown", CodeMirror.commands.removeSearch);
					editor.on("keydown", CodeMirror.commands.removeSearch);
				}
			});
})();