// CodeMirror, copyright (c) by Marijn Haverbeke and others
// Distributed under an MIT license: http://codemirror.net/LICENSE

(function(mod) {
  if (typeof exports == "object" && typeof module == "object") // CommonJS
    mod(require("../../lib/codemirror"));
  else if (typeof define == "function" && define.amd) // AMD
    define(["../../lib/codemirror"], mod);
  else // Plain browser env
    mod(CodeMirror);
})(function(CodeMirror) {
  "use strict";
  var preCM = undefined;
   CodeMirror.defineOption("fullScreen", false, function(cm, val, old) {
	if (old == CodeMirror.Init)
		return;
	if ($("#overlay").length){
		setNormal(preCM);
		preCM = undefined;
	} else {
		preCM = cm;
		setFullscreen(cm);
	}
  });

  function setFullscreen(cm, event) {
	var overlay = $('<div id="overlay" style="position: absolute;top: 0;left: 0; width: 100%;height: 102%;background-color: #0a001f;z-index: 10000;"> </div>'),
		top = $(document).scrollTop();
		$(document.body).css("overflow", "hidden");
		overlay.appendTo(document.body);
		
	var cmTemp = CodeMirror(
		function(elt) {
			overlay.append(elt);
		}, {
			value: cm.getValue(),
			theme: "night",
			mode: {name: "javascript", globalVars: true},
			highlightSelectionMatches: {showToken: /\w/, delay: 3000},
			matchBrackets: true,
			lineNumbers: true,
			lineWrapping: true,
			extraKeys: {
				"Ctrl-Space": function(cm, event){cm.showHint({hint: CodeMirror.hint.anyword});},
				"Insert": function(cm, event){return},
				"Alt-F": "findPersistent",
				"F11": function() {
					var cursor = cmTemp.getCursor();
					cm.setValue(cmTemp.getValue());					
					cm.refresh();
					$("#overlay").remove();
					cm.focus();
					cm.setCursor({line: cursor.line , ch : cursor.ch});
					$(document.body).css("overflow", "auto");
					$(document).scrollTop(top);
					cm.scrollIntoView({line: cursor.line, ch: cursor.ch}, cm.getScrollerElement().offsetHeight / 2);
				}
			}
		});
		cmTemp.on("mousedown", CodeMirror.commands.removeSearch);
		cmTemp.on("keydown", CodeMirror.commands.removeSearch);
		
	setTimeout(function(){
		var cursor = cm.getCursor();
		cmTemp.focus();
		cmTemp.setCursor({line: cursor.line , ch : cursor.ch});
		cmTemp.scrollIntoView({line: cursor.line, ch: cursor.ch}, cmTemp.getScrollerElement().offsetHeight / 2);
		cm.setValue("");
		cm.refresh();
	}, 1);
  }

  function setNormal(cm) {
	$("#overlay").remove();
	setTimeout(function(){cm.focus()}, 1);
  }
});