var port = chrome.runtime.connectNative('pk.qwerty12.ahkhrome');
	port.onDisconnect.addListener(function onDisconnected() { port = null;});

var isCopied = (function(){
	var isCopied = false, messageRegex = /^\*\*copied\*\*(\w+)$/i
	port.onMessage.addListener(function (msg) {
		if (messageRegex.test(msg)){
			try {
				isCopied = JSON.parse(messageRegex.exec(msg)[1]);
			} catch (error) {
				isCopied = false
			}
		}
	});
	return function(){
		var retVal = isCopied ? true: false;
			isCopied = false;
		return retVal
	}
})();


chrome.browserAction.onClicked.addListener(function(tab) {
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
		chrome.tabs.sendMessage(tabs[0].id, {show: "fullscreen"});
	});
});

chrome.commands.onCommand.addListener(function(command) {
	if ( command == "open_in_firefox" ) {
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {	
			tabs.length && port && port.postMessage(tabs[0].url);
		});
	}
});

chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {	
		if (request.message == "close-tab"){
			// sendResponse({farewell: "goodbye"+fileSystem});
			chrome.tabs.remove(sender.tab.id);
		} else if (request.message == "new-tab"){
			var conf = {
				active:true,
				index: (sender.tab.index+1)
			}
			if (request.url) conf['url'] = request.url
			chrome.tabs.create(conf);
		} else if (request.message == "read-clipboard") {
			port && port.postMessage("**copy**");
			setTimeout(function(){
				if (isCopied()){
					bg = chrome.extension.getBackgroundPage();

					bg.document.body.innerHTML= "";
					var helperdiv = bg.document.createElement("div");
					document.body.appendChild(helperdiv);
					helperdiv.contentEditable = true;

					// focus the helper div's content
					var range = document.createRange();
					range.selectNode(helperdiv);
					window.getSelection().removeAllRanges();
					window.getSelection().addRange(range);
					helperdiv.focus();    

					// trigger the paste action
					bg.document.execCommand("Paste");

					// read the clipboard contents from the helperdiv
					var clipboardContents = helperdiv.innerText;
					document.body.removeChild(helperdiv);

					clipboardContents.length && chrome.tabs.sendMessage(sender.tab.id, {clipboard: clipboardContents});
				}
			}, 1000);
		} else if (request.message == "speak") {
			dictionaryTTS.speak(request.text, sender.tab.id);
		} else if (request.message == "speak-toggle") {
			dictionaryTTS.toggle();
		} else if (request.message == "speak-stop") {
			dictionaryTTS.stop();
		}
	}
);

chrome.webRequest.onBeforeRequest.addListener(
	function(e) {
		chrome.tabs.update(e.tabId, {url: 'http://i.zubayer.com/code?url='+e.url});
		return {cancel: true};
	},
	{
		urls: ["*://gist.githubusercontent.com/*", "*://raw.githubusercontent.com/*"],
		types: ["main_frame"],
	},
	["blocking"]
);

var dictionaryTTS = (function () {
	var ChromeTTS = (function () {
		var tts = chrome.tts, voiceName;
		chrome.tts.getVoices( function(voices) {
			for (var i = 0; i < voices.length; i++) {
				if (!voices[i].remote && voices[i].lang == "en-US" && voices[i].gender == "female") {
					voiceName = voices[i].voiceName;
					break;
				}
			}
		});
		return function () {
			var paused = false;
			this.speak = function (text, tabId) {
				tts.isSpeaking(function (speaking) {
					if (speaking) {
						tts.stop();
					}
					tts.speak( text, { 
						voiceName: voiceName, 
						rate: 0.7,
						desiredEventTypes: ["sentence"],
						onEvent: (function () {
							var isFirst = true;
							return function (event) {
								if (isFirst) {
									isFirst = false;
								} else chrome.tabs.sendMessage(tabId, { leader: true, index: event.charIndex });
							}
						})()
					});
				});
			}
			this.toggle = function () {
				tts.isSpeaking(function (speaking) {
					if (speaking && !paused) {
						tts.pause();
						paused = true;
					} else {
						paused = false
						tts.resume();
					}
				});
			}
			this.stop = function() {
				paused = false;
				tts.stop();
			}
		}
	})();

	var tts = new ChromeTTS();
	return {
		speak: function (text, tabId) {
			tts.speak(text, tabId)
		},
		toggle: function () {
			tts.toggle();
		},
		stop: function () {
			tts.stop();
		}
	}
	
})();


(function oldSchool() {
	// Reference to the active tab
	var activeTab = null,
			mru = {};
		
	var _existingTabToTop, putExistingTabToTop = _existingTabToTop = function(windowId, tabId) {
		if (!mru[windowId]) mru[windowId] = [] 
		var index = mru[windowId].indexOf(tabId);
		if(index != -1) {
			mru[windowId].splice(index, 1);
		}
		mru[windowId].unshift(tabId);
	}

	var removeTabFromMRU = function(windowId, tabId) {
		if (!mru[windowId]) return;
		var index = mru[windowId].indexOf(tabId);
		if(index != -1) {
			mru[windowId].splice(index, 1);
		}
	}

	// Update cached ref to active tab
	function updateActiveTab() {
	  chrome.tabs.query({currentWindow: true, active: true}, function(tabs) {
			if (activeTab === null) {
				initEventHandlers();
			}
			activeTab = tabs[0];
			putExistingTabToTop(activeTab.windowId, activeTab.id);
		});
	}
  
	// Get active tab reference on startup
	updateActiveTab();
  
	// As getting active tab id at startup is async, really start our own
	// activity until we actually have it.
	// This is called in updateActiveTab if activeTab is null.
	function initEventHandlers() {
	  // Update reference to active tab any time there's a tab
	  // activated event.
	  chrome.tabs.onActivated.addListener(function(activeInfo) {
			chrome.tabs.get(activeInfo.tabId, function(tabInfo) {
				if (chrome.runtime.lastError) {
				} else {
					activeTab = tabInfo;
					if (putExistingTabToTop) {
						putExistingTabToTop(activeTab.windowId, activeTab.id);
					} else {
						putExistingTabToTop = _existingTabToTop
					}
				}
			});
		});
		
		chrome.tabs.onRemoved.addListener(function (tabId, removeInfo) {
			if (removeInfo.isWindowClosing && mru[removeInfo.windowId]) {
				delete mru[removeInfo.windowId] 
			} else { 
				putExistingTabToTop = undefined
				removeTabFromMRU(removeInfo.windowId, tabId);
				let _w = mru[removeInfo.windowId];
				_w && _w[0] && chrome.tabs.update( _w[0], {
					active: true
				});
			}
		});
  
	  // Any time a new tab is created, set its index to the index
	  // of the active tab, plus one.
	  chrome.tabs.onCreated.addListener(makeRight);
  
	  // ODD. If instead of this, I get a fresh reference to the active tab
	  // right before moving, it still has stale index!!
	  // Soooo, I guess we're doing this.
	  chrome.tabs.onMoved.addListener(updateActiveTab);
	}
  
	// Move the referenced tab to the immediate right of the active tab,
	// or to the immediate right of the last pinned tab.
	function makeRight(newTab) {
	  // Too soon after startup.
	  if (!activeTab) {
		return;
	  }
  
	  // The new tab either dragged to new window or something went wrong.
	  if (newTab.windowId != activeTab.windowId) {
		return;
	  }
  
	  var targetIndex = activeTab.index + 1;
  
	  // Only bother moving if it wouldn't organically be placed immediately to the
	  // right of the active tab.
	  if (newTab.index == targetIndex) {
		return;
	  }
  
	  // We need current window for a few things required for correct tab placement.
	  // And apparently tab references go STALE. Dammit.
	  chrome.windows.getCurrent({populate: true}, function(win) {
  
		// Maybe is a restored tab, or another add-on, or something else is wonky.
		if (newTab.index < win.tabs.length - 1
			|| newTab.index > win.tabs.length - 1) {
		  return;
		}
  
		// If the active tab is pinned, we have to set the target index
		// to that of the first non-pinned tab.
		if (activeTab.pinned) {
		  targetIndex = getFirstNonPinnedTab(win).index;
		}
  
		// YOU GOT TO MOVE IT MOVE IT
		chrome.tabs.move(newTab.id, { index: targetIndex }, function(t) {
		  // woohoo.
		});
	  });
	}
  
	// Return a tab object for the first non-pinned tab in the tab strip
	// for the given window.
	function getFirstNonPinnedTab(win) {
	  for (var tab of win.tabs) {
		if (!tab.pinned) {
		  return tab;
		}
	  }
	}
})();