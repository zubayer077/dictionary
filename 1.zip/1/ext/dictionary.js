var elem, 
	paragraphArray = [], 
	body = document.querySelectorAll("body")[0] || document.body,
	regex = /(<([^>]+)>)|_|(\t\r\n|\t\n|\t\r|\r\n|\n|\r|\t)/ig,
	thirdClicked = undefined,
	leaderTransition;

body.addEventListener("click", function(event){
	if (event){
		if(event.detail == 2){
			setTimeout( function(){
				var selObj = window.getSelection();
				if ((""+selObj).length>0 && !thirdClicked){
					// var selRange = "http://www.dictionary.reference.com/browse/"+selObj.getRangeAt(0);
					var selRange = "http://www.google.com/search?q="+selObj;
					chrome.runtime.sendMessage({message: "new-tab", url: selRange});
					selObj.removeAllRanges();
				} else
					thirdClicked = undefined;
			}, 500);
		} else if (event.detail == 3){
			thirdClicked = true;
			var selObj = window.getSelection(),
				selTxt = ""+selObj.getRangeAt(0);
			if (selTxt.length>0){
				leaderTransition = undefined;
				chrome.runtime.sendMessage({message: "speak", text: foldToASCII(selTxt).replace(regex, " ")});
			}
			selObj.removeAllRanges();
		} else {
			chrome.runtime.sendMessage({message: "speak-toggle"});
		}
	}
});

document.oncontextmenu = function(e){
	chrome.runtime.sendMessage({message: "speak-stop"});
	if(e.ctrlKey)
		return;
	if (e && e.stopPropagation)
		e.stopPropagation();
	return false;
}

body.addEventListener("mouseup", function(event){
	if(event.ctrlKey)
		return;
	if (event.which == 3){
		elem = event.target;
		
		while (elem && elem.nodeName!="P"){
			elem = elem.parentNode;
		}
		
		if (!elem){
			var tag = event.target;
			while (tag && !new RegExp("li|tr|dd").test(tag.nodeName.toLowerCase())){
				tag = tag.parentNode;
			}
			
			if (tag){
				elem = tag; paragraphArray = [];
			} else return;
		} else paragraphArray = [];
		
		readAloud(elem);
		(function searchParent(searchCh, name, className){
			if (searchCh.nextSibling)
				searchChild(searchCh.nextSibling, name, className);
			if (searchCh && searchCh.parentElement)
				searchParent(searchCh.parentElement, name, className);
		})(elem, elem.nodeName, ""+elem.className);
	}
	return;
});
function searchChild(searchCh, name, className){
	if (((searchCh.nodeName == name && (""+searchCh.className).indexOf(className)>-1)|| searchCh.nodeName == "P")
			&& (""+searchCh.textContent).length>3)
		paragraphArray.push(searchCh);
	if(searchCh.hasChildNodes())
		searchChild(searchCh.firstChild, name, className);
	if(searchCh.nextSibling)
		searchChild(searchCh.nextSibling, name, className);
	else return;
}

function readAloud(elem){
	var text = elem.textContent,
		bgColor = window.getComputedStyle(elem).getPropertyValue("background-color") || "transparent",
		lastIndexAt = 0;
	
	text = foldToASCII(text).replace(regex, " ").trim();
	setTimeout(function(){
		chrome.runtime.sendMessage({message: "speak", text: text});
	}, 1);

 	elem.style.transition = "background-color 500ms";
	elem.style.backgroundColor = "#8CC2FF";
	setTimeout(function(){
		elem.style.transition = "background-color 2s";
		elem.style.backgroundColor = bgColor;
	}, 500);
	
	leaderTransition = function (charIndex) {
		var html = elem.innerHTML,
			fontSize = window.getComputedStyle(elem).getPropertyValue("font-size") || "inherit",
			text = elem.textContent.replace(regex, " ").trim(),
			currentIndex = 0, 
			subStr = text.substring(charIndex);
		
		lastIndexAt = lastIndexAt || charIndex;
		while (subStr.length) {
			subStr = subStr.replace(/\b(\w+\W*)$/gi, "");
			if (html.indexOf(subStr, lastIndexAt) > -1 ) {
				currentIndex = html.indexOf(subStr, lastIndexAt);
				break;
			}
		}
		if (charIndex && currentIndex) {
			var span = document.createElement("span");
				span.style.border = 0;
				span.style.margin = 0;
				span.style.fontSize = fontSize;
				span.style.padding = 0;
				span.className = "leader";

			var repTxt	= html.substring(currentIndex);
				repTxt = repTxt.substring(0, repTxt.search(/<([^>]+)>/gi) > -1? repTxt.search(/<([^>]+)>/gi): repTxt.length);
				repTxt = repTxt.substring(0, 10);
			span.appendChild(document.createTextNode(repTxt));
			elem.innerHTML = html.substring(0, currentIndex) + span.outerHTML+ html.substring(currentIndex + repTxt.length);

			lastIndexAt = currentIndex + repTxt.length;
			$(elem).find("span.leader").last().animate({
				backgroundColor:'#8CC2FF'
			}, 100).animate({
				backgroundColor:'transparent'
			}, 1000, function () {
				elem.innerHTML = html;
			});
		}
	}
	return;
}

function isInput(focusedEl) {
	if (focusedEl) {
	   var focusedElLn = focusedEl.nodeName.toLowerCase();
	   if (focusedElLn === "input"
		 ||  focusedElLn === "textarea"
/*		  ||  focusedElLn === "select"
		 ||  focusedElLn === "button"*/
		 ||  focusedElLn === "isindex") {
	   return true;
	   } else if (focusedElLn === "div" && focusedEl.isContentEditable) {
			 return true;
	   }
   }
   return false;
};

function stopPropagation(event){
	event.preventDefault();
	event.stopImmediatePropagation();
	event.stopPropagation();
	return true;
};

window.addEventListener("keydown", function(event){
	var key = event.keyCode,
		node = event.target;
		
	if(key == 39){
		if(event.ctrlKey || event.altKey || isInput(node))
			return;
		stopPropagation(event);
		var paragraph, elementTop = undefined, text = undefined, inner = window.innerHeight, innerThird = Math.floor(inner/3);
		while(paragraphArray.length>0 && 
			((!text || (""+text).length<4) || (!elementTop || (elementTop.top<innerThird && !(elementTop.bottom>innerThird))))){
			try{
				paragraph = paragraphArray.shift();
				text = foldToASCII(paragraph.textContent).replace(regex, " ") || undefined;
				elementTop = paragraph.getBoundingClientRect() || undefined;
			} catch (err){}
		}
		
		if (paragraph){
			readAloud(paragraph);
			var innerHalf = inner/2;
			if (elementTop.top > innerHalf && elementTop.bottom > inner){
				window.scrollBy(0, Math.floor(elementTop.top - innerHalf));
			}
		} else {
			window.scrollBy(0, Math.floor((2*inner)/3));
		}
		return false;
	}
	
	if(key == 46||key == 88){
		if(event.ctrlKey || isInput(node))
			return;
		stopPropagation(event);
		chrome.runtime.sendMessage({message: "close-tab"});
		return;
	}
	if (key == 90){
		if (history.length>1 && !isInput(node)){
			stopPropagation(event);
			history.go(-1);
			return false;
		}
	}
	if (key == 107){
		chrome.runtime.sendMessage({message: "new-tab"});
		return;
	}

	if (key == 192){
		if(event.ctrlKey){
			var selObj = undefined;
			if (isInput(event.target)){
				var selectedTextArea = document.activeElement;
				selObj = selectedTextArea.value.substring(selectedTextArea.selectionStart, selectedTextArea.selectionEnd);
			} else
				selObj = window.getSelection();
				
			if ((""+selObj).length>0){
				leaderTransition = undefined;
				var selTxt = Object.prototype.toString.call(selObj) == '[object String]'? selObj:(""+selObj.getRangeAt(0));
				chrome.runtime.sendMessage({message: "speak", text: foldToASCII(selTxt).replace(regex, " ")});
			}
			selObj.removeAllRanges();
		}
		return;
	}
});
[].forEach.call(
	document.querySelectorAll("p"),
	function(el){
		paragraphArray.push(el);
	}
);


var anotherDom = document.createElement("div");
	document.body.appendChild(anotherDom);
var shadow = anotherDom.attachShadow({mode: 'open'});
// var shadow = document.body;
function showCodeMirror(selRange){
	var c = document.createElement("div"),
		_viewFullScreen = document.createElement('div');

	var style = document.createElement('style');
		style.textContent = `
		all: initial;
		* {
			all: revert;
		}
		
		html, body, div, span, object, iframe,
		h1, h2, h3, h4, h5, h6, p, blockquote, pre,
		abbr, address, cite, code,
		del, dfn, em, img, ins, kbd, q, samp,
		small, strong, sub, sup, var,
		b, i,
		dl, dt, dd, ol, ul, li,
		fieldset, form, label, legend,
		table, caption, tbody, tfoot, thead, tr, th, td,
		article, aside, canvas, details, figcaption, figure, 
		footer, header, hgroup, menu, nav, section, summary,
		time, mark, audio, video {
			margin:0;
			padding:0;
			border:0;
			outline:0;
			font-size:100%;
			vertical-align:baseline;
			background: transparent;
		}

		pre {
			background: transparent !important;
		}
		
		body {
			line-height:1;
		}
		
		article,aside,details,figcaption,figure,
		footer,header,hgroup,menu,nav,section { 
			display:block;
		}
		
		nav ul {
			list-style:none;
		}
		
		blockquote, q {
			quotes:none;
		}
		
		blockquote:before, blockquote:after,
		q:before, q:after {
			content:'';
			content:none;
		}
		
		a {
			margin:0;
			padding:0;
			font-size:100%;
			vertical-align:baseline;
			background:transparent;
		}
		
		ins {
			background-color:#ff9;
			color:#000;
			text-decoration:none;
		}
		
		mark {
			background-color:#ff9;
			color:#000; 
			font-style:italic;
			font-weight:bold;
		}
		
		del {
			text-decoration: line-through;
		}
		
		abbr[title], dfn[title] {
			border-bottom:1px dotted;
			cursor:help;
		}
		
		table {
			border-collapse:collapse;
			border-spacing:0;
		}
		
		hr {
			display:block;
			height:1px;
			border:0;   
			border-top:1px solid #cccccc;
			margin:1em 0;
			padding:0;
		}
		
		input, select {
			vertical-align:middle;
		}
		`;
	var urls = ["data/codemirror.css", "data/dialog.css", "data/show-hint.css", "data/night.css", "data/simplescrollbars.css", "data/ChangeMirror.css"],
		requests = urls.map(function(url){
			return $.get(chrome.extension.getURL(url), function(css){
				style.textContent = style.textContent + `
				${css}
				`;
			});
		});

	$.when.apply($, requests).then(function(){
		shadow.appendChild(style);
		style.onload = setTimeout(function() {
			var val = selRange;
				val = val.slice(val.match(/^\s*/)[0].length, val.length - val.match(/\s*$/)[0].length);

			var editor = CodeMirror(function(elt) {
				c.style.border = 0;
				c.style.margin = 0;
				c.style.padding = 0;
				c.style.backgroundColor="#0a001f";
				
				var d = document.createElement('div'),
					cLine = selRange.split(/\r\n|\r|\n/).length,
					totalLineHeight = (cLine*1.5*12);
				if( totalLineHeight > window.screen.height )
					d.style.height = window.screen.height+"px";
				d.appendChild(elt);
				c.innerHTML = "";
				c.appendChild(d);
			}, {
				value: val,
				lineNumbers: true,
				theme: "night",
				autofocus: true,
				// extraKeys: {"Ctrl-Space": "autocomplete","Alt-F": "findPersistent"},
				extraKeys: {
					"Ctrl-Space": function(cm, event){cm.showHint({
						hint: CodeMirror.hint.anyword,
						container: _viewFullScreen
					});},
					"Insert": function(cm, event){return},
					"Alt-F": "findPersistent"
				},
				mode: {name: "javascript", globalVars: true},
				highlightSelectionMatches: {showToken: /\w/, delay: 3000},
				matchBrackets: true,
				viewportMargin: Infinity,
				lineWrapping: true,
				scrollbarStyle: "overlay"
			});
			editor.on("mousedown", CodeMirror.commands.removeSearch);
			editor.on("keydown", CodeMirror.commands.removeSearch);

			var keyListener = function name(evt) {
				if (typeof evt.stopPropagation == "function") {
					evt.stopPropagation();
				} else {
					evt.cancelBubble = true;
				}
			}, mirrorWrapper = editor.getWrapperElement();
			mirrorWrapper.addEventListener("keydown", keyListener);
			mirrorWrapper.addEventListener("keyup", keyListener);
			mirrorWrapper.addEventListener("keypress", keyListener);

			_viewFullScreen.addEventListener("webkitfullscreenchange", function () {
				if (document.webkitIsFullScreen){
		
				} else{
					_viewFullScreen.removeEventListener("webkitfullscreenchange", this);
					mirrorWrapper.removeEventListener("keydown", keyListener);
					mirrorWrapper.removeEventListener("keyup", keyListener);
					mirrorWrapper.removeEventListener("keypress", keyListener);
					shadow.removeChild(style)
					shadow.removeChild(_viewFullScreen);
				}
			}, false);
		}, 1)
	});
	_viewFullScreen.appendChild(c);
	shadow.appendChild(_viewFullScreen);
	_viewFullScreen.webkitRequestFullScreen();
}

var getTextFromSelection = function (selObj){
	var selRange = selObj.getRangeAt(0);
	var node = selRange.commonAncestorContainer;
	while (!(node.innerText && node.innerText.length)){
		node = node.parentNode;
	}
	selRange = node.innerText;
	return selRange
}

chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		if (request.show) {
			var selRange = "", selObj = window.getSelection();
			/* rangeCount works fines when selObj.toString is empty
			if(selObj.rangeCount){ */
			if ((""+selObj).length>0) {
				selRange = getTextFromSelection(selObj);
				showCodeMirror(selRange);
			} else {
				selObj = undefined;
				$("iframe").each(function(i, frame) {
					try { // somtimes document have access to iframe
						var iframeSelection = frame.contentWindow.getSelection(); 
						if (iframeSelection.toString().length > 0) { selObj = iframeSelection; }	
					} catch (error) {}
				});
				if (selObj) {
					selRange = getTextFromSelection(selObj);
					selObj.removeAllRanges(); // because iframes keep their individual selections
					showCodeMirror(selRange);
				} else {
					chrome.runtime.sendMessage({message: "read-clipboard"});
				}
			}
		} else if (request.clipboard) {
			showCodeMirror(request.clipboard);
		} else if (request.leader) {
			if (leaderTransition) leaderTransition(request.index);
		}
	});
