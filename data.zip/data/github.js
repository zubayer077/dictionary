(function(){
	var c = document.getElementsByTagName("body")[0], val = c.textContent || c.innerText;
		val = val.slice(val.match(/^\s*/)[0].length, val.length - val.match(/\s*$/)[0].length);
	
	var editor = CodeMirror(function(elt) {
			c.style.border = 0;
			c.style.margin = 0;
			c.style.padding = 0;
			c.style.backgroundColor="#0a001f";
			
			var d = document.createElement('div'),
				cLine = c.innerHTML.split(/\r\n|\r|\n/).length;
			// d.style.height = (cLine*1.5)+"em";
			d.style.height = "100%";
			d.appendChild(elt);
			c.innerHTML = "";
			c.appendChild(d);
		}, {
		  value: val,
			lineNumbers: true,
			theme: "night",
			autofocus: true,
			// extraKeys: {"Ctrl-Space": "autocomplete","Alt-F": "findPersistent"},
			extraKeys: {
				"Ctrl-Space": function(cm, event){cm.showHint({hint: CodeMirror.hint.anyword});},
				"Ctrl-F11": function(cm, event){cm.setOption('lineWrapping', !cm.getOption('lineWrapping'));},
				"Insert": function(cm, event){return},
				"Alt-F": "findPersistent"
			},
			mode: {name: "javascript", globalVars: true},
			highlightSelectionMatches: {showToken: /\w/, delay: 3000},
			matchBrackets: true
		});
	editor.on("mousedown", CodeMirror.commands.removeSearch);
	editor.on("keydown", CodeMirror.commands.removeSearch);
})();