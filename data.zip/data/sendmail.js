(function($){
	$("<style type='text/css'> #overlay { font-family: 'Open Sans', serif; font-size: 15px;} #overlay form { position:fixed; bottom: 5px; right: 5px;border-left: 20px solid transparent;} #sendemail{width:450px; min-height:200px; border: 1px solid #fff;padding: 10px 10px 0 10px; font-family: 'Open Sans', serif; font-size: 15px;line-height: 26px;} </style>").appendTo("head");
	
	$(document.body).css("overflow", "hidden");
	var overlay = $('<div id="overlay" style="position: fixed;top: 0;left: 0;width: 100%;height: 100%;background-color: #fff;z-index: 10000;"> <form action=\"sendemail\" onsubmit=\"return false\" method=\"post\"><textarea id=\"sendemail\" spellcheck=\"true\" autofocus></textarea></form></div>');
	overlay.appendTo(document.body);
	
	
	window.lastText = { since : Date.now(), timeChanged : false};
	var _currentColor = $("#overlay form, #sendemail"), _sendMail = $("#sendemail").focus(), sugg = _sendMail.asuggest([]);

	setInterval(function(){	
		if (window.lastText.timeChanged && (Date.now() - window.lastText.since)>1000){
			_currentColor.css("color", "#EEE");
			window.lastText.timeChanged = false;
		}
	}, 500);
	
	function addWord(){
		setTimeout(function(){
			var lastWords = _sendMail.val().match(/\S*(\S+)\s$/) || undefined;
				if (lastWords && lastWords[0]){
					var lastWord = lastWords[0].replace(/[^\w\s]/g, "").trim();
					for (l=0;l<sugg.suggests.length;++l){
						if (sugg.suggests[l]===lastWord){
							sugg.suggests.splice(l, 1);
							break;
						}
					}
					sugg.suggests.unshift(lastWord);
				}
		},1);
		return;
	}

	$("#overlay form").on("keyup", function(event){
		var target = event.target, sugg_val = target.value;
		if (/\S*(\S+)\s$/.test(sugg_val) && sugg_val.length == target.selectionEnd){
			addWord();
		}
		return;
	}).on("keypress", function(event){
		if (!(event.altKey || event.ctrlKey)){
			if (event.which == 13) {
				var content = _sendMail.val().replace(/(\r\n|\n|\r)/gm,"").trim();
				if (content.length<1) return;
			
				$("#text-inner textarea").val(content); 
				$("#send_button").click();
				setTimeout(function(){
					_sendMail.val('').focus();
					content.split(" ").forEach(function(el){
						var lastWord = el.replace(/[^\w\s]/g, "").trim();
						for (l=0;l<sugg.suggests.length;++l){
							if (sugg.suggests[l]===lastWord){
								sugg.suggests.splice(l, 1);
								break;
							}
						}
						sugg.suggests.unshift(lastWord);
					});
				}, 10);
			}
			if (!window.lastText.timeChanged) _currentColor.css("color", "black");
			window.lastText = { since : Date.now(), timeChanged : true};
		}
	});
	
	$(window).on("blur focus", function(e) {
		var prevType = $(this).data("prevType");
		
		if (prevType != e.type) {
			switch (e.type) {
				case "focus":
					setTimeout(function(){_sendMail.focus();}, 100);
				break;
			}
		}
		
		$(this).data("prevType", e.type);
	});

})($);